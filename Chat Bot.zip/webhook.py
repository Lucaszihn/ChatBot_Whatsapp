"""Webhook do WhatsApp Cloud API.

Regras de ouro:
1. Validar a assinatura (X-Hub-Signature-256) antes de confiar no payload.
2. Responder 200 rapidamente: nada de chamar LLM aqui, só enfileirar.
"""
import hashlib
import hmac
import logging

from fastapi import APIRouter, Header, HTTPException, Query, Request, Response

from app.core.config import settings
from app.workers.tasks import processar_mensagem

router = APIRouter(prefix="/webhook/whatsapp", tags=["whatsapp"])
log = logging.getLogger(__name__)


@router.get("")
async def verificar(
    hub_mode: str = Query(alias="hub.mode"),
    hub_verify_token: str = Query(alias="hub.verify_token"),
    hub_challenge: str = Query(alias="hub.challenge"),
):
    """Handshake feito pela Meta ao cadastrar o webhook."""
    token_ok = hmac.compare_digest(hub_verify_token, settings.meta_verify_token)
    if hub_mode == "subscribe" and token_ok:
        return Response(content=hub_challenge, media_type="text/plain")
    raise HTTPException(status_code=403, detail="token de verificação inválido")


def _assinatura_valida(corpo: bytes, cabecalho: str | None) -> bool:
    if not cabecalho or not cabecalho.startswith("sha256="):
        return False
    esperado = hmac.new(
        settings.meta_app_secret.encode(), corpo, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(esperado, cabecalho.removeprefix("sha256="))


@router.post("")
async def receber(
    request: Request,
    x_hub_signature_256: str | None = Header(default=None),
):
    corpo = await request.body()
    if not _assinatura_valida(corpo, x_hub_signature_256):
        raise HTTPException(status_code=403, detail="assinatura inválida")

    payload = await request.json()

    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            phone_number_id = value.get("metadata", {}).get("phone_number_id")
            nomes = {
                c.get("wa_id"): c.get("profile", {}).get("name")
                for c in value.get("contacts", [])
            }
            # "statuses" (entregue/lido) não vêm em "messages", então são ignorados aqui
            for msg in value.get("messages", []):
                processar_mensagem.delay(
                    phone_number_id=phone_number_id,
                    wa_from=msg["from"],
                    wa_message_id=msg["id"],
                    tipo=msg.get("type", "unknown"),
                    texto=msg.get("text", {}).get("body"),
                    nome=nomes.get(msg["from"]),
                )

    # A Meta reenvia se não receber 200 rápido
    return {"status": "ok"}
