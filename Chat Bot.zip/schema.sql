-- Modelo de dados multiempresa. Toda tabela de negócio carrega empresa_id.

CREATE TABLE empresas (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome         text NOT NULL,
    tom_de_voz   text,
    instrucoes   text,                       -- regras da empresa: horários, política de desconto, etc.
    ativa        boolean NOT NULL DEFAULT true,
    criada_em    timestamptz NOT NULL DEFAULT now()
);

-- Um número de WhatsApp (phone_number_id da Meta) pertence a uma empresa
CREATE TABLE canais_whatsapp (
    id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id       bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    phone_number_id  text NOT NULL UNIQUE,
    numero_exibicao  text,
    access_token     text NOT NULL           -- cifre em repouso em produção (KMS/pgcrypto)
);

CREATE TABLE produtos (
    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id      bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    nome            text NOT NULL,
    descricao       text,
    preco_centavos  integer NOT NULL CHECK (preco_centavos >= 0),
    estoque         integer CHECK (estoque >= 0),   -- NULL = sem controle de estoque (ex.: serviços)
    ativo           boolean NOT NULL DEFAULT true,
    busca           tsvector GENERATED ALWAYS AS (
        to_tsvector('portuguese', coalesce(nome, '') || ' ' || coalesce(descricao, ''))
    ) STORED
);
CREATE INDEX ix_produtos_empresa ON produtos (empresa_id) WHERE ativo;
CREATE INDEX ix_produtos_busca ON produtos USING gin (busca);

-- Base de conhecimento (FAQ, políticas). Busca por texto no MVP.
-- Para busca semântica: CREATE EXTENSION vector; e adicionar coluna embedding vector(N).
CREATE TABLE documentos_conhecimento (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id  bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    titulo      text NOT NULL,
    conteudo    text NOT NULL,
    busca       tsvector GENERATED ALWAYS AS (
        to_tsvector('portuguese', coalesce(titulo, '') || ' ' || conteudo)
    ) STORED
);
CREATE INDEX ix_docs_empresa ON documentos_conhecimento (empresa_id);
CREATE INDEX ix_docs_busca ON documentos_conhecimento USING gin (busca);

-- Cliente final no WhatsApp (um por empresa)
CREATE TABLE contatos (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id  bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    wa_id       text NOT NULL,               -- número do cliente no formato da Meta
    nome        text,
    criado_em   timestamptz NOT NULL DEFAULT now(),
    UNIQUE (empresa_id, wa_id)
);

CREATE TABLE conversas (
    id                    bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id            bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    contato_id            bigint NOT NULL REFERENCES contatos(id) ON DELETE CASCADE,
    estado                text NOT NULL DEFAULT 'bot' CHECK (estado IN ('bot', 'humano', 'encerrada')),
    motivo_transferencia  text,
    criada_em             timestamptz NOT NULL DEFAULT now(),
    atualizada_em         timestamptz NOT NULL DEFAULT now()
);
-- No máximo uma conversa aberta por contato
CREATE UNIQUE INDEX ux_conversa_aberta ON conversas (contato_id) WHERE estado IN ('bot', 'humano');
CREATE INDEX ix_conversas_empresa_estado ON conversas (empresa_id, estado);

CREATE TABLE mensagens (
    id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id     bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    conversa_id    bigint NOT NULL REFERENCES conversas(id) ON DELETE CASCADE,
    direcao        text NOT NULL CHECK (direcao IN ('entrada', 'saida')),
    conteudo       text NOT NULL,
    wa_message_id  text,                     -- id da Meta: garante idempotência
    criada_em      timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ux_mensagens_wa ON mensagens (empresa_id, wa_message_id) WHERE wa_message_id IS NOT NULL;
CREATE INDEX ix_mensagens_conversa ON mensagens (conversa_id, id);

CREATE TABLE pedidos (
    id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id     bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    conversa_id    bigint REFERENCES conversas(id) ON DELETE SET NULL,
    contato_id     bigint NOT NULL REFERENCES contatos(id),
    status         text NOT NULL DEFAULT 'aberto'
                   CHECK (status IN ('aberto', 'aguardando_pagamento', 'pago', 'cancelado')),
    total_centavos integer NOT NULL CHECK (total_centavos >= 0),
    criado_em      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_pedidos_empresa_status ON pedidos (empresa_id, status);

CREATE TABLE itens_pedido (
    id                    bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    pedido_id             bigint NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
    produto_id            bigint NOT NULL REFERENCES produtos(id),
    nome_snapshot         text NOT NULL,     -- nome e preço no momento da compra
    quantidade            integer NOT NULL CHECK (quantidade > 0),
    preco_unit_centavos   integer NOT NULL CHECK (preco_unit_centavos >= 0)
);

CREATE TABLE pagamentos (
    id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    empresa_id       bigint NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
    pedido_id        bigint NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
    psp              text NOT NULL,
    psp_cobranca_id  text NOT NULL,
    metodo           text NOT NULL CHECK (metodo IN ('pix', 'cartao', 'boleto')),
    status           text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'falhou', 'estornado')),
    valor_centavos   integer NOT NULL CHECK (valor_centavos >= 0),
    criado_em        timestamptz NOT NULL DEFAULT now(),
    pago_em          timestamptz,
    UNIQUE (psp, psp_cobranca_id)            -- o webhook do PSP pode chegar repetido
);
CREATE INDEX ix_pagamentos_pedido ON pagamentos (pedido_id);
